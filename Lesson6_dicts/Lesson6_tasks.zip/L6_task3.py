result_list = [tuple(i for i in range(1,11)), tuple(j**2 for j in range(1,11))]
print(result_list)