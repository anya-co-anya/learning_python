# A simple function.
# Create a simple function called favorite_movie, which takes a string containing the name of your favorite movie.
# The function should then print “My favorite movie is named {name}”.

def print_favourite_movie(name):
    print(f'Wow! My favourite movie is also {name}')


print_favourite_movie(input('What is your favourite movie? '))
