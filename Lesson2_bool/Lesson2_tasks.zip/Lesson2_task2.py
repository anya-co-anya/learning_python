first_name = 'Mark'
last_name = 'Vovk'

print('Hi, ' + first_name + ' ' + last_name)